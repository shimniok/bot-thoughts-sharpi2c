#include "mbed.h"

DigitalOut myled(LED1);
I2C i2c(p28, p27);       // sda, scl
Serial pc(USBTX, USBRX); // tx, rx
Timer t;

int addr = 0x26;

int main() {
    
    i2c.frequency(100000);
    pc.baud(115200);
    pc.printf("Hello world!\n");
    t.start();
    t.reset();
    while(1) {
        char data[3];

        if ( i2c.read(addr<<1, data, 2) != 0) {
            pc.printf("no response from %d\n", addr);
        } else {
            int value;
            value = data[0]<<8 | data[1];
            pc.printf("%d %d\n", t.read_ms(), value);
        }
    }
}
